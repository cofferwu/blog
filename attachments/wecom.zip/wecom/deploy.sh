#!/usr/bin/env bash
# authentik 企业微信扫码登录部署助手（扫码取 userid + 属性映射输出邮箱，volume 模式）
#
#   ./deploy.sh check      检查 compose 文件、镜像版本、容器状态
#   ./deploy.sh prepare    从运行容器取出 apps.py 并打两处补丁
#   ./deploy.sh config     用完整文件列表跑 docker compose config 并确认挂载生效
#   ./deploy.sh enable     把完整文件列表写进 .env 的 COMPOSE_FILE（幂等）
#   ./deploy.sh verify     部署后检查类型注册
#   ./deploy.sh diagnose   向导里看不到 WeCom 时，打印被吞掉的真实 traceback
#
# 需要放在 compose.yml 同级目录的文件：
#   deploy.sh  compose.wecom-volume.yml  wecom.py  wecom_model.py
#   patch_apps.py  diagnose_wecom.py
#   create_wecom_source.py  create_wecom_mapping.py
#   icons/wecom/*.svg
# apps.py 由 prepare 自动生成，不要从别处复制。
#
# 部署顺序：
#   ./deploy.sh check
#   docker compose up -d
#   ./deploy.sh prepare
#   ./deploy.sh config
#   ./deploy.sh enable
#   docker compose up -d --force-recreate server worker
#   ./deploy.sh verify

set -euo pipefail
cd "$(dirname "$0")"

info() { printf '\033[1;34m[信息]\033[0m %s\n' "$*"; }
ok()   { printf '\033[1;32m[完成]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[注意]\033[0m %s\n' "$*"; }
fail() { printf '\033[1;31m[失败]\033[0m %s\n' "$*" >&2; exit 1; }

usage() {
    cat <<'EOF'
用法: ./deploy.sh <check|prepare|config|enable|verify|diagnose>

脚本须与 compose.yml 放在同一目录。改过任何自定义 Python 文件后必须
--force-recreate 重建 server 与 worker，volume 不会热更新已 import 的模块。
可用环境变量: BASE_FILE（默认自动探测）/ AK_SERVICE（server）/ AK_WORKER（worker）
EOF
}

case "${1:-}" in
    ""|-h|--help) usage; exit 1 ;;
esac

COMPOSE_V2=0
if docker compose version >/dev/null 2>&1; then
    COMPOSE_V2=1
elif ! command -v docker-compose >/dev/null 2>&1; then
    fail "未找到 docker compose / docker-compose"
fi

dc() {
    if [ "$COMPOSE_V2" = 1 ]; then docker compose "${COMPOSE_ARGS[@]}" "$@";
    else docker-compose "${COMPOSE_ARGS[@]}" "$@"; fi
}

PY=""
for c in python3 python; do
    if command -v "$c" >/dev/null 2>&1; then PY="$c"; break; fi
done

BASE_FILE="${BASE_FILE:-}"
if [ -z "$BASE_FILE" ]; then
    for f in compose.yml compose.yaml docker-compose.yml docker-compose.yaml; do
        if [ -f "$f" ]; then BASE_FILE="$f"; break; fi
    done
fi
[ -n "$BASE_FILE" ] || fail "当前目录未找到 compose.yml，请用 BASE_FILE 指定"

# 命令行一旦出现 -f，Compose 就不再自动加载 override，必须显式带上用户原有的。
COMPOSE_ARGS=(-f "$BASE_FILE")
OVERRIDE_FILES=()
for f in compose.override.yml compose.override.yaml docker-compose.override.yml docker-compose.override.yaml; do
    if [ -f "$f" ]; then OVERRIDE_FILES+=("$f"); COMPOSE_ARGS+=(-f "$f"); fi
done

DEPLOY_FILES=(compose.wecom-volume.yml)
for f in "${DEPLOY_FILES[@]}"; do
    [ -f "$f" ] || fail "缺少 $f，请从交付包补齐"
done

dc_all() {
    local args=("${COMPOSE_ARGS[@]}")
    local f
    for f in "${DEPLOY_FILES[@]}"; do args+=(-f "$f"); done
    if [ "$COMPOSE_V2" = 1 ]; then docker compose "${args[@]}" "$@";
    else docker-compose "${args[@]}" "$@"; fi
}

AK_SERVICE="${AK_SERVICE:-server}"
AK_WORKER="${AK_WORKER:-worker}"
container_id() { dc ps -q "$AK_SERVICE" 2>/dev/null | head -n 1 || true; }
compose_prefix() { if [ "$COMPOSE_V2" = 1 ]; then echo "docker compose"; else echo "docker-compose"; fi; }

cmd_check() {
    info "基础 compose 文件 : $BASE_FILE"
    [ "${#OVERRIDE_FILES[@]}" -gt 0 ] && info "原有 override       : ${OVERRIDE_FILES[*]}"
    info "部署文件           : ${DEPLOY_FILES[*]}"
    if [ "$COMPOSE_V2" = 1 ]; then docker compose version; else docker-compose version; fi
    local image
    image="$(dc config --images 2>/dev/null | grep 'goauthentik/server' | head -n 1 || true)"
    [ -n "$image" ] || fail "无法从 compose 配置读出 authentik 镜像"
    info "authentik 镜像     : $image"
    local svcs
    svcs="$(dc_all config --services 2>/dev/null || true)"
    printf '%s\n' "$svcs" | sed 's/^/   服务: /'
    printf '%s\n' "$svcs" | grep -qx "$AK_SERVICE" || warn "未找到服务 $AK_SERVICE"
    printf '%s\n' "$svcs" | grep -qx "$AK_WORKER" || warn "未找到服务 $AK_WORKER"
    local cid
    cid="$(container_id)"
    if [ -n "$cid" ]; then info "server 容器         : ${cid:0:12}（运行中）"; else warn "$AK_SERVICE 容器未运行，prepare 需要它先启动"; fi
    [ -n "$PY" ] && info "宿主机 Python       : $PY" || warn "宿主机无 python3，prepare 无法自动打补丁"
}

cmd_prepare() {
    for f in wecom.py wecom_model.py patch_apps.py; do
        [ -f "$f" ] || fail "缺少 $f"
    done
    [ -n "$PY" ] || fail "宿主机需要 python3 来给 apps.py 打补丁"
    local cid
    cid="$(container_id)"
    [ -n "$cid" ] || fail "$AK_SERVICE 容器未运行，先执行 $(compose_prefix) -f $BASE_FILE up -d"

    info "从运行容器取出 apps.py（保证与当前镜像版本一致）"
    docker cp "$cid:/authentik/sources/oauth/apps.py" ./apps.py
    "$PY" patch_apps.py ./apps.py
    "$PY" -c "import ast; [ast.parse(open(p, encoding='utf-8').read()) for p in ['./apps.py', './wecom.py', './wecom_model.py']]"
    grep -q 'authentik.sources.oauth.types.wecom' ./apps.py || fail "注册项写入失败"
    grep -q 'def import_models' ./apps.py || fail "import_models() 钩子写入失败"
    chmod 644 ./apps.py ./wecom.py ./wecom_model.py
    ok "apps.py / wecom.py / wecom_model.py 已就绪（权限 644）"
    echo
    info "下一步："
    echo "    ./deploy.sh config"
    echo "    ./deploy.sh enable"
    echo "    $(compose_prefix) up -d --force-recreate $AK_SERVICE $AK_WORKER"
    echo "    ./deploy.sh verify"
}

cmd_config() {
    local rendered
    rendered="$(dc_all config 2>&1)" || fail "docker compose config 执行失败:\n$rendered"
    if printf '%s\n' "$rendered" | grep -qF '/authentik/sources/oauth/types/wecom.py'; then
        ok "合并后的配置已包含自定义 SourceType 挂载"
    else
        fail "合并后未找到 wecom.py 挂载，检查 -f 顺序与服务名"
    fi
    echo
    info "相关片段："
    printf '%s\n' "$rendered" | grep -n -B2 -A4 -E 'wecom\.py|wecom_model\.py|icons/wecom' | head -60 || true
}

cmd_enable() {
    local sep env_file=.env value old f
    sep="${COMPOSE_PATH_SEPARATOR:-:}"
    local -a files=("$BASE_FILE")
    for f in "${OVERRIDE_FILES[@]}"; do files+=("$f"); done
    for f in "${DEPLOY_FILES[@]}"; do files+=("$f"); done

    if [ -f "$env_file" ] && grep -q '^COMPOSE_FILE=' "$env_file"; then
        old="$(grep '^COMPOSE_FILE=' "$env_file" | tail -n 1 | cut -d= -f2-)"
        value="$old"
        for f in "${files[@]}"; do
            case "$old" in
                *"$f"*) ;;
                *) value="${value}${sep}${f}" ;;
            esac
        done
    else
        value="$(IFS="$sep"; printf '%s' "${files[*]}")"
    fi

    if [ -f "$env_file" ]; then
        cp -p "$env_file" "$env_file.wecom-bak"
        ok "已备份 $env_file -> $env_file.wecom-bak"
    else
        : > "$env_file"
        ok "已创建 $env_file"
    fi

    awk -v val="$value" '
        /^COMPOSE_FILE=/ { if (!done) { print "COMPOSE_FILE=" val; done=1 }; next }
        { print }
        END { if (!done) { print ""; print "COMPOSE_FILE=" val } }
    ' "$env_file" > "$env_file.tmp" && mv "$env_file.tmp" "$env_file"

    ok "已写入 .env：COMPOSE_FILE=$value"
    if [ -n "${COMPOSE_FILE:-}" ]; then
        warn "当前 shell 里 export 了 COMPOSE_FILE=$COMPOSE_FILE，优先级高于 .env；请 unset 或同步该值"
    fi
}

cmd_verify() {
    local cid
    cid="$(container_id)"
    [ -n "$cid" ] || fail "$AK_SERVICE 容器未运行"
    info "检查容器内文件与类型注册"
    docker exec "$cid" /ak-root/.venv/bin/python -c "
import ast, os, django, pathlib
paths = ['/authentik/sources/oauth/types/wecom.py',
         '/authentik/sources/oauth/wecom_model.py',
         '/authentik/sources/oauth/apps.py']
for p in paths:
    print(' ', p, 'exists =', pathlib.Path(p).is_file())
    if pathlib.Path(p).is_file(): ast.parse(pathlib.Path(p).read_text())
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'authentik.root.settings')
django.setup()
from authentik.core.models import Source
from authentik.core.api.object_types import CreatableType
from authentik.lib.utils.reflection import all_subclasses
from authentik.sources.oauth.types.registry import registry
names = [n for n, _ in registry.get_name_tuple()]
models = [c.__name__ for c in all_subclasses(Source)
          if c._meta.abstract and issubclass(c, CreatableType)]
print('  registry 含 wecom          :', 'wecom' in names)
print('  向导含 WeComOAuthSource    :', 'WeComOAuthSource' in models)
print('  提示: 邮箱由属性映射输出，建源后运行 create_wecom_mapping.py')
print('RESULT:', 'OK' if 'wecom' in names and 'WeComOAuthSource' in models else 'MISSING')
" || warn "容器内检查失败，执行 ./deploy.sh diagnose 查看详细错误"
    info "向导类型列表失败时执行 ./deploy.sh diagnose"
}

cmd_diagnose() {
    [ -f diagnose_wecom.py ] || fail "缺少 diagnose_wecom.py"
    local cid
    cid="$(container_id)"
    [ -n "$cid" ] || fail "$AK_SERVICE 容器未运行"
    docker cp diagnose_wecom.py "$cid:/tmp/diagnose_wecom.py" >/dev/null || fail "docker cp 失败"
    docker exec "$cid" /ak-root/.venv/bin/python /tmp/diagnose_wecom.py \
        || warn "诊断脚本执行失败，请把完整输出发回"
}

case "${1:-}" in
    check)    cmd_check ;;
    prepare)  cmd_prepare ;;
    config)   cmd_config ;;
    enable)   cmd_enable ;;
    verify)   cmd_verify ;;
    diagnose) cmd_diagnose ;;
    *)        usage; exit 1 ;;
esac
