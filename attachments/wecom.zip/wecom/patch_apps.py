"""给容器内的 sources/oauth/apps.py 打两处幂等补丁。

1. 把 authentik.sources.oauth.types.wecom 加入 AUTHENTIK_SOURCES_OAUTH_TYPES，
   否则 types/wecom.py 不会被导入，registry 里没有 wecom。
2. 覆写 import_models()，在 Django 加载模型时导入 wecom_model.py。
   向导的类型列表来自 Source.__subclasses__()，必须在此时机创建 model 子类。

必须作用于从当前运行镜像取出的 apps.py，升级 authentik 后要重新 prepare。

用法：python patch_apps.py ./apps.py
"""

from __future__ import annotations

import sys
from pathlib import Path

MODULE = "authentik.sources.oauth.types.wecom"
LIST_MARKER = "AUTHENTIK_SOURCES_OAUTH_TYPES = ["
IMPORT_MARKER = "def import_models"
ANCHORS = ("    def import_related(self):", "    @property\n    def schedule_specs")

IMPORT_MODELS = '''    def import_models(self):
        """Load the WeCom wizard model while Django imports models."""
        super().import_models()
        from importlib import import_module

        import_module("authentik.sources.oauth.wecom_model")

'''


def patch(path: str) -> int:
    target = Path(path)
    if not target.is_file():
        print(f"ERROR: {path} not found", file=sys.stderr)
        return 1

    text = target.read_text(encoding="utf-8")
    original = text
    changed = []

    if f'"{MODULE}"' not in text:
        if LIST_MARKER not in text:
            print("ERROR: AUTHENTIK_SOURCES_OAUTH_TYPES not found", file=sys.stderr)
            return 1
        text = text.replace(LIST_MARKER, f'{LIST_MARKER}\n    "{MODULE}",', 1)
        changed.append("registry import list")
    else:
        print(f"already registered: {MODULE}")

    if IMPORT_MARKER not in text:
        anchor = next((a for a in ANCHORS if a in text), None)
        if anchor is None:
            print("ERROR: no safe insertion point found", file=sys.stderr)
            return 1
        text = text.replace(anchor, IMPORT_MODELS + anchor, 1)
        changed.append("import_models() hook")
    else:
        print("already present: import_models() hook")

    if text != original:
        target.write_text(text, encoding="utf-8")
        print(f"patched {path}: " + ", ".join(changed))
    else:
        print(f"nothing to do, {path} is already fully patched")
    return 0


if __name__ == "__main__":
    sys.exit(patch(sys.argv[1] if len(sys.argv) > 1 else "./apps.py"))
