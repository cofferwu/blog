"""在 authentik 容器内诊断 WeCom 类型注册，打印被 import_related 吞掉的真实异常。

用法：./deploy.sh diagnose
"""

from __future__ import annotations

import importlib
import os
import pathlib
import traceback

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "authentik.root.settings")

FILES = {
    "types/wecom.py": "/authentik/sources/oauth/types/wecom.py",
    "wecom_model.py": "/authentik/sources/oauth/wecom_model.py",
    "apps.py": "/authentik/sources/oauth/apps.py",
}
MODULES = (
    "authentik.core.api.object_types",
    "authentik.sources.oauth.wecom_model",
    "authentik.sources.oauth.types.wecom",
)


def section(title: str) -> None:
    print()
    print("=" * 68)
    print(title)
    print("=" * 68)


def main() -> None:
    import django

    django.setup()

    from authentik.core.api.object_types import CreatableType
    from authentik.core.models import Source
    from authentik.lib.utils.reflection import all_subclasses
    from authentik.sources.oauth.types.registry import registry

    section("1. 容器内文件")
    contents = {}
    for label, path in FILES.items():
        try:
            text = pathlib.Path(path).read_text(encoding="utf-8")
        except OSError:
            text = ""
        contents[label] = text
        print(f"  {label:18} exists={bool(text)}  bytes={len(text)}")
    apps_py = contents["apps.py"]
    print("  apps.py 含 types.wecom 注册项 :",
          "authentik.sources.oauth.types.wecom" in apps_py)
    print("  apps.py 含 import_models 钩子 :", "def import_models" in apps_py)

    section("2. 主动导入（绕开 import_related 吞掉的 ImportError）")
    for mod in MODULES:
        try:
            importlib.import_module(mod)
            print(f"  OK      {mod}")
        except Exception:
            print(f"  FAILED  {mod}")
            traceback.print_exc(limit=8)

    section("3. 两个互相独立的类型列表")
    names = [n for n, _ in registry.get_name_tuple()]
    models = [
        c.__name__
        for c in all_subclasses(Source)
        if c._meta.abstract and issubclass(c, CreatableType)
    ]
    in_registry = "wecom" in names
    in_wizard = "WeComOAuthSource" in models
    print("  registry 含 wecom               :", in_registry)
    print("  向导 model 含 WeComOAuthSource :", in_wizard)
    print("  registry 全部内容              :", names)

    section("结论")
    if in_registry and in_wizard:
        print("  RESULT: OK —— 两个下拉都会出现 WeCom / 企业微信。")
    elif not contents["wecom_model.py"]:
        print("  RESULT: NOT_DEPLOYED —— 容器里没有 wecom_model.py，重新 prepare 并 --force-recreate。")
    elif "def import_models" not in apps_py:
        print("  RESULT: APPS_NOT_PATCHED —— 重新执行 ./deploy.sh prepare。")
    elif not in_registry:
        print("  RESULT: REGISTRY_MISSING —— 看第 2 节 traceback 与启动日志的 Failed to load OAuth Source。")
    else:
        print("  RESULT: WIZARD_MISSING —— 确认容器已重建（volume 改文件不会热更新）。")


if __name__ == "__main__":
    main()
