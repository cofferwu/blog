"""在 authentik 容器内诊断 WeCom / DingTalk 类型注册与钉钉通讯录邮箱输出。

用法：./deploy.sh diagnose
      DINGTALK_UNION_ID=<unionId> ./deploy.sh diagnose   # 实测通讯录企业/员工邮箱
"""

from __future__ import annotations

import importlib
import os
import pathlib
import sys
import traceback

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "authentik.root.settings")

FILES = {
    "types/wecom.py": "/authentik/sources/oauth/types/wecom.py",
    "wecom_model.py": "/authentik/sources/oauth/wecom_model.py",
    "types/dingtalk.py": "/authentik/sources/oauth/types/dingtalk.py",
    "dingtalk_model.py": "/authentik/sources/oauth/dingtalk_model.py",
    "apps.py": "/authentik/sources/oauth/apps.py",
}
MODULES = (
    "authentik.core.api.object_types",
    "authentik.sources.oauth.wecom_model",
    "authentik.sources.oauth.dingtalk_model",
    "authentik.sources.oauth.types.wecom",
    "authentik.sources.oauth.types.dingtalk",
)
TYPE_MODULES = (
    "authentik.sources.oauth.types.wecom",
    "authentik.sources.oauth.types.dingtalk",
)
WIZARD_IMPORTS = (
    'import_module("authentik.sources.oauth.wecom_model")',
    'import_module("authentik.sources.oauth.dingtalk_model")',
)


def section(title: str) -> None:
    print()
    print("=" * 68)
    print(title)
    print("=" * 68)


def probe_contact(union_id: str) -> None:
    """只读实测：应用凭证 -> unionId/userid -> 通讯录企业/员工邮箱。"""
    section("5. 钉钉通讯录邮箱实测")
    if not union_id:
        print("  未指定 unionId，跳过实测。用法：")
        print("    DINGTALK_UNION_ID=<unionId> ./deploy.sh diagnose")
        return

    import requests

    from authentik.sources.oauth.models import OAuthSource

    source = OAuthSource.objects.filter(provider_type="dingtalk").first()
    if not source:
        print("  未找到 provider_type=dingtalk 的源，先在管理界面配置")
        return
    try:
        token_response = requests.post(
            "https://api.dingtalk.com/v1.0/oauth2/accessToken",
            json={"appKey": source.consumer_key, "appSecret": source.consumer_secret},
            timeout=10,
        )
        token_data = token_response.json()
        token = token_data.get("accessToken") or ""
        print("  应用 token :", token_response.status_code,
              "OK" if token else str(token_data)[:200])
        if not token:
            print("  结论: 应用凭证无效，检查 Client ID / Client Secret 与应用类型")
            return

        union_response = requests.post(
            "https://oapi.dingtalk.com/topapi/user/getbyunionid",
            params={"access_token": token},
            data={"unionid": union_id},
            timeout=10,
        )
        union_data = union_response.json()
        userid = (union_data.get("result") or {}).get("userid") or union_data.get("userid") or ""
        if not userid:
            fallback = requests.get(
                "https://oapi.dingtalk.com/user/getUseridByUnionid",
                params={"access_token": token, "unionid": union_id},
                timeout=10,
            )
            userid = fallback.json().get("userid") or ""
        print("  unionId -> userid :", userid or str(union_data)[:200])
        if not userid:
            print("  结论: unionId 换 userid 失败，检查「成员信息读权限」")
            return

        detail_response = requests.post(
            "https://oapi.dingtalk.com/topapi/v2/user/get",
            params={"access_token": token},
            data={"userid": userid, "language": "zh_CN"},
            timeout=10,
        )
        detail_data = detail_response.json()
        detail = detail_data.get("result") or {}
        org_email = detail.get("org_email") or detail.get("orgEmail") or ""
        employee_email = detail.get("email") or ""
        print("  ORG EMAIL     (org_email) :", org_email or "<空>")
        print("  EMPLOYEE EMAIL     (email) :", employee_email or "<空>")
        if not (org_email or employee_email):
            print("  结论: 两个邮箱字段都为空，检查通讯录「邮箱等个人信息」权限并发布新版本")
            return

        from authentik.core.models import User

        hits = [candidate for candidate in (org_email, employee_email)
                if candidate and User.objects.filter(email__iexact=candidate).exists()]
        print("  命中现有用户的候选         :", hits or "无")
        print("  结论:", "email_link 可关联现有用户" if hits
              else "无匹配邮箱，需统一两侧邮箱；否则登录会新建用户")
    except Exception as exc:
        print("  实测失败:", type(exc).__name__, str(exc)[:200])


def main() -> None:
    import django

    django.setup()

    from authentik.core.api.object_types import CreatableType
    from authentik.core.models import Source
    from authentik.lib.utils.reflection import all_subclasses
    from authentik.sources.oauth.types.registry import registry

    section("1. 容器内文件")
    contents = {}
    for label, path in FILES.items():
        try:
            text = pathlib.Path(path).read_text(encoding="utf-8")
        except OSError:
            text = ""
        contents[label] = text
        print(f"  {label:20} exists={bool(text)}  bytes={len(text)}")
    apps_py = contents["apps.py"]
    for mod in TYPE_MODULES:
        print(f"  apps.py 含 {mod.split('.')[-1]} 注册项 :", f'"{mod}"' in apps_py)
    print("  apps.py 含 import_models 钩子 :", "def import_models" in apps_py)
    for label, imp in (("wecom_model", WIZARD_IMPORTS[0]),
                       ("dingtalk_model", WIZARD_IMPORTS[1])):
        print(f"  apps.py 含 {label:16} 向导导入 :", imp in apps_py)

    section("2. 主动导入（绕开 import_related 吞掉的 ImportError）")
    for mod in MODULES:
        try:
            importlib.import_module(mod)
            print(f"  OK      {mod}")
        except Exception:
            print(f"  FAILED  {mod}")
            traceback.print_exc(limit=8)

    section("3. 两个互相独立的类型列表")
    names = [n for n, _ in registry.get_name_tuple()]
    models = [
        c.__name__
        for c in all_subclasses(Source)
        if c._meta.abstract and issubclass(c, CreatableType)
    ]
    in_registry = {n: n in names for n in ("wecom", "dingtalk")}
    in_wizard = {n: n in models for n in ("WeComOAuthSource", "DingTalkOAuthSource")}
    print("  registry 含 wecom               :", in_registry["wecom"])
    print("  registry 含 dingtalk            :", in_registry["dingtalk"])
    print("  向导 model 含 WeComOAuthSource  :", in_wizard["WeComOAuthSource"])
    print("  向导 model 含 DingTalkOAuthSource:", in_wizard["DingTalkOAuthSource"])
    print("  registry 全部内容               :", names)

    section("4. 钉钉邮箱输出与源配置")
    email_ok = False
    if in_registry["dingtalk"]:
        dt = registry.find_type("dingtalk")()
        sample = {"unionId": "u1", "openId": "o1", "nick": "test"}
        org = dt.get_base_user_properties(
            info=dict(sample, org_email="Test.User@zjtdemo.cloud"))
        employee = dt.get_base_user_properties(
            info=dict(sample, employee_email="Staff.User@zjtdemo.cloud"))
        no_email = dt.get_base_user_properties(info=sample)
        print("  样例(企业邮箱) email :", org.get("email"))
        print("  样例(员工邮箱) email :", employee.get("email"))
        print("  样例(无邮箱)   email :", repr(no_email.get("email")))
        print("  企业邮箱写入 attributes:", org["attributes"]["dingtalk_org_email"])
        email_ok = (bool(org.get("email")) and bool(employee.get("email"))
                    and not no_email.get("email"))
    else:
        print("  registry 无 dingtalk，跳过邮箱自检")
    print("  EMAIL :", "OK" if email_ok else "MISSING")

    try:
        from authentik.sources.oauth.models import OAuthSource

        sources = list(OAuthSource.objects.filter(provider_type="dingtalk"))
        if not sources:
            print("  钉钉源 : 尚未创建（在管理界面配置）")
        for s in sources:
            maps = list(s.user_property_mappings.values_list("name", flat=True))
            print(f"  钉钉源 {s.slug} | matching={s.user_matching_mode} | mappings={maps}")
            if maps:
                print("  警告: 仍绑定属性映射，会覆盖内置 email，请在界面清空 User property mappings")
            if s.user_matching_mode != "email_link":
                print("  警告: User matching mode 需设为 email_link")
    except Exception as exc:
        print("  源配置检查跳过 :", type(exc).__name__, str(exc)[:120])

    probe_contact(sys.argv[1] if len(sys.argv) > 1 else "")

    section("结论")
    if all(in_registry.values()) and all(in_wizard.values()) and email_ok:
        print("  RESULT: OK —— 两个下拉都会出现，钉钉邮箱按通讯录企业/员工邮箱内置输出。")
    elif not contents["dingtalk_model.py"] or not contents["types/dingtalk.py"]:
        print("  RESULT: NOT_DEPLOYED —— 容器里缺 dingtalk 文件，重新 prepare 并 --force-recreate。")
    elif not all(imp in apps_py for imp in WIZARD_IMPORTS):
        print("  RESULT: APPS_NOT_PATCHED —— 重新执行 ./deploy.sh prepare。")
    elif not in_registry["dingtalk"]:
        print("  RESULT: REGISTRY_MISSING —— 看第 2 节 traceback 与启动日志的 Failed to load OAuth Source。")
    elif not email_ok:
        print("  RESULT: EMAIL_MISSING —— 检查 dingtalk.py 的 get_base_user_properties 与容器是否已重建。")
    else:
        print("  RESULT: WIZARD_MISSING —— 确认容器已重建（volume 改文件不会热更新）。")


if __name__ == "__main__":
    main()
