"""在管理界面「新建源」向导中提供 DingTalk / 钉钉 类型。

本模块由 patch_apps.py 注入的 import_models() 在 Django 加载模型阶段导入。
向导的类型列表来自 Source.__subclasses__()，与 SourceType registry 相互独立。
"""

from authentik.core.api.object_types import CreatableType
from authentik.sources.oauth.models import OAuthSource


class DingTalkOAuthSource(CreatableType, OAuthSource):
    """Social login using DingTalk (钉钉). 源在管理界面图形化配置。"""

    class Meta:
        abstract = True
        app_label = "authentik_sources_oauth"
        verbose_name = "DingTalk / 钉钉"
        verbose_name_plural = "DingTalk / 钉钉 Sources"
