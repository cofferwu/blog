#!/bin/bash
set -euo pipefail

APP_KEY="dingilf49vpw94wa8q4o"
APP_SECRET="FVHvxto_xPCWoh7pTah5fMVIqxaHKUdMD3NLE6TXC4PdLUqLXzkastXqA8KnU56A"
CORP_ID="ding6e8540fd352447830dcd7849bbb3a871"
USER_ID="0238183112-196122819"

echo ">>> 正在获取 access_token ..."

TOKEN_RESP=$(curl -s -X POST "https://api.dingtalk.com/v1.0/oauth2/accessToken" \
  -H "Content-Type: application/json" \
  -d "{\"appKey\":\"${APP_KEY}\",\"appSecret\":\"${APP_SECRET}\"}")

echo "Token 原始返回: $TOKEN_RESP"

ACCESS_TOKEN=$(echo "$TOKEN_RESP" | python3 -c "import sys,json; print(json.load(sys.stdin)['accessToken'])")

echo "access_token: $ACCESS_TOKEN"

echo ">>> 正在查询用户邮箱 ..."

USER_RESP=$(curl -s -X POST "https://oapi.dingtalk.com/topapi/v2/user/get?access_token=${ACCESS_TOKEN}" \
  -H "Content-Type: application/x-www-form-urlencoded;charset=utf-8" \
  --data-urlencode "userid=${USER_ID}")

echo "用户详情原始返回: $USER_RESP"

EMAIL=$(echo "$USER_RESP" | python3 -c "import sys,json; print(json.load(sys.stdin).get('result',{}).get('email',''))")

echo "email: $EMAIL"