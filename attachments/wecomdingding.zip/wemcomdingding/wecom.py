"""企业微信扫码登录 Source：只取 userid，邮箱由属性映射输出。

登录链路：
    PC 浏览器 -> 企业微信扫码页(qrConnect) -> 手机确认
    -> 企业微信回传 code -> auth/getuserinfo 取 userid
    -> OAuth Source Property Mapping 输出邮箱（忽略大小写匹配现有用户）
    -> email_link 关联现有用户

邮箱不在本模块生成。企业微信源需在管理界面绑定 OAuth Source Property Mapping
（本包不提供建映射脚本）：用 ak_user_by(email__iexact=...) 忽略大小写回查
现有用户，返回其实际存储的 email 供 email_link 的 email__exact 命中；
查不到时返回 <userid>@zjtdemo.cloud。未绑定映射时 email 缺失，登录会被拒绝。
现有环境中已绑定的映射不受影响。

管理界面建源：
    Consumer key          CorpID:AgentID
    Consumer secret       自建应用 Secret
    Authorization URL     https://open.work.weixin.qq.com/wwopen/sso/qrConnect
    Scopes                留空
    User matching mode    email_link
    User property mappings  wecom-userid-email
    Authentication flow   default-source-authentication
    Enrollment flow       default-source-enrollment

前提：
    现有 authentik 用户的 email 忽略大小写后等于 <企业微信userid>@zjtdemo.cloud，
    且不存在仅大小写不同的重复邮箱账号；
    企业微信后台「Web 登录」授权回调域为 auth.zjtdemo.cloud；
    回调走 nginx 443 正式证书；测试成员在应用可见范围内。

可选环境变量（server 与 worker 保持一致）：
    AUTHENTIK_WECOM_AGENT_ID       consumer_key 未写 CorpID:AgentID 时指定

图标：
    icon_url() 返回 /static/authentik/sources/wecom.svg，由 compose 把
    icons/wecom.svg 挂载到 /web/authentik/sources/wecom.svg 提供。

向导里的「企业微信」类型由 wecom_model.py 提供，注册依赖 patch_apps.py
对容器 apps.py 的两处补丁。
"""

from __future__ import annotations

import os
from hashlib import sha256
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse

from django.core.cache import cache
from django.templatetags.static import static
from requests.exceptions import RequestException

from authentik.sources.oauth.clients.oauth2 import OAuth2Client
from authentik.sources.oauth.types.registry import SourceType, registry
from authentik.sources.oauth.views.callback import OAuthCallback
from authentik.sources.oauth.views.redirect import OAuthRedirect

QRCONNECT_URL = "https://open.work.weixin.qq.com/wwopen/sso/qrConnect"
GETTOKEN_URL = "https://qyapi.weixin.qq.com/cgi-bin/gettoken"
GETUSERINFO_URL = "https://qyapi.weixin.qq.com/cgi-bin/auth/getuserinfo"


class WeComOAuth2Client(OAuth2Client):
    """构造扫码链接，并把回调 code 换成企业微信 userid。"""

    def _credentials(self) -> tuple[str, str]:
        corp_id, _, inline_agent = (self.source.consumer_key or "").partition(":")
        authorization_url = self.source.authorization_url or ""
        url_args = dict(parse_qsl(urlparse(authorization_url).query, keep_blank_values=True))
        agent_id = (
            inline_agent.strip()
            or os.environ.get("AUTHENTIK_WECOM_AGENT_ID", "").strip()
            or url_args.get("agentid", "").strip()
        )
        return corp_id.strip(), agent_id

    def get_redirect_url(self, parameters=None) -> str:
        """只把基类生成的 redirect_uri 与 state 带进扫码链接。

        state 由基类写入 session 并在 callback 校验，必须原样保留。
        """
        args = dict(parse_qsl(urlparse(super().get_redirect_url(parameters)).query,
                              keep_blank_values=True))
        corp_id, agent_id = self._credentials()
        if not corp_id:
            self.logger.warning("WeCom CorpID is missing: 检查源的 Consumer key")
        if not agent_id:
            self.logger.warning(
                "WeCom AgentID is missing: Consumer key 请写成 CorpID:AgentID，"
                "或设置 AUTHENTIK_WECOM_AGENT_ID"
            )
        query: dict[str, str] = {"appid": corp_id}
        if agent_id:
            query["agentid"] = agent_id
        query["redirect_uri"] = args.get("redirect_uri", "")
        query["state"] = args.get("state", "")
        return QRCONNECT_URL + "?" + urlencode(query)

    def _corp_token(self) -> str | None:
        corp_id, _ = self._credentials()
        secret = self.source.consumer_secret
        key = "wecom-corp-token-" + sha256(f"{corp_id}:{secret}".encode()).hexdigest()[:24]
        try:
            cached = cache.get(key)
            if cached:
                return cached
        except Exception:
            pass

        try:
            response = self.do_request(
                "get", GETTOKEN_URL,
                params={"corpid": corp_id, "corpsecret": secret},
            )
            response.raise_for_status()
            data = response.json()
        except (RequestException, ValueError) as exc:
            self.logger.warning("WeCom gettoken failed", exc=exc)
            return None
        if data.get("errcode", 0) != 0:
            self.logger.warning(
                "WeCom gettoken error",
                errcode=data.get("errcode"), errmsg=data.get("errmsg"),
            )
            return None
        token = data.get("access_token")
        if token:
            try:
                cache.set(key, token, timeout=max(60, int(data.get("expires_in", 7200)) - 300))
            except Exception:
                pass
        return token

    def get_access_token(self, **request_kwargs) -> dict[str, Any] | None:
        if not self.check_application_state():
            return {"error": "State check failed."}
        code = self.get_request_arg("code", None)
        if not code:
            return {
                "error": self.get_request_arg("error_description")
                or self.get_request_arg("error")
                or "No code returned by WeCom."
            }

        access_token = self._corp_token()
        if not access_token:
            return None

        try:
            response = self.do_request(
                "get", GETUSERINFO_URL,
                params={"access_token": access_token, "code": code},
            )
            response.raise_for_status()
            identity = response.json()
        except (RequestException, ValueError) as exc:
            self.logger.warning("WeCom getuserinfo failed", exc=exc)
            return None

        if identity.get("errcode", 0) != 0:
            self.logger.warning(
                "WeCom getuserinfo error",
                errcode=identity.get("errcode"), errmsg=identity.get("errmsg"),
            )
            return {"error": f"getuserinfo: {identity.get('errmsg')}"}
        userid = identity.get("userid")
        if not userid:
            self.logger.warning(
                "WeCom returned no userid: 检查 AgentID 与成员是否在应用可见范围内"
            )
            return {"error": "WeCom returned no userid."}
        return {
            "access_token": access_token,
            "token_type": "Bearer",
            "userid": userid,
            "expires_in": 7200,
        }

    def get_profile_info(self, token: dict[str, Any]) -> dict[str, Any] | None:
        """扫码登录只提供 userid，不调用任何敏感信息接口。"""
        userid = token.get("userid")
        if not userid:
            return None
        return {"id": userid, "userid": userid}


class WeComOAuthRedirect(OAuthRedirect):
    client_class = WeComOAuth2Client


class WeComOAuth2Callback(OAuthCallback):
    client_class = WeComOAuth2Client

    def get_user_id(self, info: dict[str, Any]) -> str | None:
        return info.get("userid") or info.get("id")


@registry.register()
class WeComType(SourceType):
    """WeCom / 企业微信 source type."""

    callback_view = WeComOAuth2Callback
    redirect_view = WeComOAuthRedirect
    verbose_name = "WeCom / 企业微信"
    name = "wecom"

    urls_customizable = True
    authorization_url = QRCONNECT_URL
    access_token_url = GETUSERINFO_URL
    profile_url = ""

    def icon_url(self) -> str:
        """返回随包挂载的企业微信图标，仅用于 SourceType 注册列表。"""
        return static("authentik/sources/wecom.svg")

    def get_base_user_properties(self, *args, **kwargs) -> dict[str, Any]:
        """只给基础属性；email 由 Source 绑定的属性映射输出。"""
        info: dict[str, Any] = kwargs.get("info") or (args[-1] if args else {})
        userid = info.get("userid") or info.get("id")
        return {
            "username": userid,
            "name": userid,
            "attributes": {
                "wecom_userid": userid,
            },
        }
