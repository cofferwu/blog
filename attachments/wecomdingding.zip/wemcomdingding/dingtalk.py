"""钉钉扫码登录 SourceType：按通讯录企业邮箱/员工邮箱匹配现有用户。

登录链路：
    PC 浏览器 -> login.dingtalk.com/oauth2/auth（scope=openid, prompt=consent）
    -> 扫码/账号确认 -> 回调 code(authCode)
    -> POST /v1.0/oauth2/userAccessToken 换个人用户 token
    -> GET /v1.0/contact/users/me 取 unionId（该接口的 email 只是个人邮箱）
    -> POST /v1.0/oauth2/accessToken 换应用 token（AppKey/AppSecret，带缓存）
    -> topapi/user/getbyunionid 把 unionId 换成 userid（失败时走
       user/getUseridByUnionid）
    -> topapi/v2/user/get 取 org_email（企业邮箱）与 email（员工邮箱）
    -> get_base_user_properties 输出 email（忽略大小写回查现有用户）
    -> email_link 关联现有用户

邮箱字段依据（钉钉开放平台「查询用户详情」）：
    org_email / orgEmail : 员工的企业邮箱，员工未开通企业邮箱时不返回该字段。
    email                : 员工邮箱（通讯录成员资料里的员工邮箱）。
    users/me 的 email    : 用户的个人邮箱，不是以上两者。

取值顺序：企业邮箱 -> 员工邮箱 -> 个人邮箱。每个候选都用 email__iexact
回查 authentik 现有用户，命中即用该用户的真实 email 输出，使 email_link
的 email__exact 查询一定命中，避免误建用户。三个字段都为空时输出空邮箱，
由 email_link 返回 DENY 拒绝登录，日志同时给出提示。

管理界面建源（本包不提供建源脚本）：
    Consumer key            Client ID（企业内部应用 AppKey）
    Consumer secret         Client Secret（AppSecret）
    User matching mode      E-mail link (email_link)
    User property mappings  留空（邮箱已由本模块输出）
    Authentication flow     default-source-authentication
    Enrollment flow         default-source-enrollment
    Additional Scopes       留空（钉钉只接受 openid / openid corpid）

前提：
    钉钉开发者后台「重定向URL（回调域名）」包含 https://auth.zjtdemo.cloud；
    回调走 nginx 443 正式证书；测试成员在应用可见范围内；
    应用已申请「通讯录个人信息读权限」(Contact.User.Read)、
    「成员信息读权限」与通讯录「企业员工手机号信息和邮箱等个人信息」，
    经管理员授权并发布新版本；
    现有 authentik 用户的 email 忽略大小写后等于上述任一钉钉邮箱。

三个端点固定在本模块，urls_customizable=False，界面无需填写 URL。
向导里的「钉钉」类型由 dingtalk_model.py 提供，注册依赖 patch_apps.py
对容器 apps.py 的补丁。
"""

from __future__ import annotations

import hashlib
import json
import logging
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse

from requests.exceptions import RequestException

from authentik.sources.oauth.clients.oauth2 import OAuth2Client
from authentik.sources.oauth.types.registry import SourceType, registry
from authentik.sources.oauth.views.callback import OAuthCallback
from authentik.sources.oauth.views.redirect import OAuthRedirect

LOGGER = logging.getLogger(__name__)

AUTH_URL = "https://login.dingtalk.com/oauth2/auth"
USER_TOKEN_URL = "https://api.dingtalk.com/v1.0/oauth2/userAccessToken"
USER_ME_URL = "https://api.dingtalk.com/v1.0/contact/users/me"
APP_TOKEN_URL = "https://api.dingtalk.com/v1.0/oauth2/accessToken"
UNION_TO_USERID_URL = "https://oapi.dingtalk.com/topapi/user/getbyunionid"
UNION_TO_USERID_LEGACY_URL = "https://oapi.dingtalk.com/user/getUseridByUnionid"
USER_DETAIL_URL = "https://oapi.dingtalk.com/topapi/v2/user/get"

JSON_HEADERS = {"Content-Type": "application/json", "Accept": "application/json"}
FORM_HEADERS = {
    "Content-Type": "application/x-www-form-urlencoded",
    "Accept": "application/json",
}


def _cache():
    """返回 Django cache；无 Django 环境时降级为不缓存。"""
    try:
        from django.core.cache import cache

        return cache
    except Exception:
        return None


def _key(prefix: str, *parts: str) -> str:
    raw = "\x00".join(parts).encode("utf-8")
    return prefix + hashlib.sha256(raw).hexdigest()[:32]


class DingTalkOAuth2Client(OAuth2Client):
    """构造钉钉授权链接，并把回调 code 换成用户身份与通讯录邮箱信息。"""

    def _scopes(self, parameters: Any) -> str:
        """默认 openid；源的 Additional Scopes 只接受 openid / openid corpid。"""
        raw = parameters.get("scope") if isinstance(parameters, dict) else None
        if isinstance(raw, str):
            items = raw.split()
        elif isinstance(raw, (list, tuple)):
            items = [str(item) for item in raw]
        else:
            items = []
        return " ".join(items) if items else "openid"

    def get_redirect_url(self, parameters=None) -> str:
        """只取基类生成的 redirect_uri 与 state，其余按钉钉参数重写。

        state 由基类写入 session 并在 callback 校验，必须原样保留。
        """
        args = dict(parse_qsl(urlparse(super().get_redirect_url(parameters)).query,
                              keep_blank_values=True))
        query: dict[str, str] = {
            "client_id": self.get_client_id() or "",
            "redirect_uri": args.get("redirect_uri", ""),
            "response_type": "code",
            "scope": self._scopes(parameters),
            "prompt": "consent",
            "state": args.get("state", ""),
        }
        return AUTH_URL + "?" + urlencode(query)

    def get_access_token(self, **request_kwargs) -> dict[str, Any] | None:
        """钉钉用 JSON body + camelCase 字段换 token，不是标准 OAuth2 form。"""
        if not self.check_application_state():
            return {"error": "State check failed."}
        # 钉钉不同文档分别用 code 与 authCode，二者一致，任一可取。
        code = self.get_request_arg("code") or self.get_request_arg("authCode")
        if not code:
            return {
                "error": self.get_request_arg("error_description")
                or self.get_request_arg("error")
                or "No code/authCode returned by DingTalk."
            }

        payload = {
            "clientId": self.get_client_id(),
            "clientSecret": self.get_client_secret(),
            "code": code,
            "grantType": "authorization_code",
        }
        try:
            response = self.do_request(
                "post", USER_TOKEN_URL,
                data=json.dumps(payload),
                headers=JSON_HEADERS,
            )
            response.raise_for_status()
            data = response.json()
        except (RequestException, ValueError) as exc:
            self.logger.warning("DingTalk userAccessToken failed", exc=exc)
            return None

        if not data.get("accessToken"):
            self.logger.warning(
                "DingTalk userAccessToken error",
                code=data.get("code"), message=data.get("message"),
            )
            return {"error": f"userAccessToken: {data.get('message') or data.get('code')}"}
        return {
            "access_token": data["accessToken"],
            "token_type": "Bearer",
            "expires_in": int(data.get("expireIn") or 7200),
            "refresh_token": data.get("refreshToken"),
            "corp_id": data.get("corpId"),
        }

    def _app_token(self) -> str:
        """用界面配置的 AppKey/AppSecret 换应用 token，并按时效缓存。"""
        client_id = self.get_client_id() or ""
        client_secret = self.get_client_secret() or ""
        if not client_id or not client_secret:
            self.logger.warning("DingTalk app credentials are missing")
            return ""

        store = _cache()
        cache_key = _key("dingtalk-app-token-", client_id, client_secret)
        cached = store.get(cache_key) if store else None
        if cached:
            return cached

        payload = {"appKey": client_id, "appSecret": client_secret}
        try:
            response = self.do_request(
                "post", APP_TOKEN_URL,
                data=json.dumps(payload),
                headers=JSON_HEADERS,
            )
            response.raise_for_status()
            data = response.json()
        except (RequestException, ValueError) as exc:
            self.logger.warning("DingTalk app accessToken failed", exc=exc)
            return ""

        token = data.get("accessToken") or ""
        if not token:
            self.logger.warning(
                "DingTalk app accessToken error",
                code=data.get("code"), message=data.get("message"),
            )
            return ""
        if store:
            ttl = max(60, min(int(data.get("expireIn") or 7200) - 120, 7000))
            store.set(cache_key, token, ttl)
        return token

    def _userid(self, token: str, union_id: str) -> str:
        """通讯录接口按 userid 查询，先把稳定的 unionId 换成 userid。"""
        store = _cache()
        cache_key = _key("dingtalk-userid-", self.get_client_id() or "", union_id)
        cached = store.get(cache_key) if store else None
        if cached:
            return cached

        userid = ""
        try:
            response = self.do_request(
                "post", UNION_TO_USERID_URL,
                params={"access_token": token},
                data={"unionid": union_id},
                headers=FORM_HEADERS,
            )
            response.raise_for_status()
            data = response.json()
            userid = (data.get("result") or {}).get("userid") or data.get("userid") or ""
        except (RequestException, ValueError) as exc:
            self.logger.warning("DingTalk unionId to userid failed", exc=exc)

        if not userid:
            # 另一个官方 unionId 换 userid 接口，参数与返回字段不同。
            try:
                response = self.do_request(
                    "get", UNION_TO_USERID_LEGACY_URL,
                    params={"access_token": token, "unionid": union_id},
                    headers={"Accept": "application/json"},
                )
                response.raise_for_status()
                userid = response.json().get("userid") or ""
            except (RequestException, ValueError) as exc:
                self.logger.warning("DingTalk unionId to userid fallback failed", exc=exc)

        if not userid:
            self.logger.warning(
                "DingTalk cannot resolve unionId to userid; 检查「成员信息读权限」",
                union_id=union_id,
            )
            return ""
        if store:
            store.set(cache_key, userid, 86400)
        return userid

    def _contact_emails(self, token: str, userid: str) -> tuple[str, str]:
        """返回（企业邮箱 org_email，员工邮箱 email）。"""
        try:
            response = self.do_request(
                "post", USER_DETAIL_URL,
                params={"access_token": token},
                data={"userid": userid, "language": "zh_CN"},
                headers=FORM_HEADERS,
            )
            response.raise_for_status()
            data = response.json()
        except (RequestException, ValueError) as exc:
            self.logger.warning("DingTalk user detail failed", exc=exc)
            return "", ""

        if str(data.get("errcode") or "0") != "0":
            self.logger.warning(
                "DingTalk user detail error",
                errcode=data.get("errcode"), errmsg=data.get("errmsg"),
            )
            return "", ""
        detail = data.get("result") or {}
        org_email = (detail.get("org_email") or detail.get("orgEmail") or "").strip()
        employee_email = (detail.get("email") or "").strip()
        return org_email, employee_email

    def get_profile_info(self, token: dict[str, Any]) -> dict[str, Any] | None:
        """钉钉用 x-acs-dingtalk-access-token 头，不是 Authorization: Bearer。"""
        access_token = (token or {}).get("access_token")
        if not access_token:
            return None
        try:
            response = self.do_request(
                "get", USER_ME_URL,
                headers={
                    "x-acs-dingtalk-access-token": access_token,
                    "Accept": "application/json",
                },
            )
            response.raise_for_status()
            info = response.json()
        except (RequestException, ValueError) as exc:
            self.logger.warning("DingTalk users/me failed", exc=exc)
            return None

        if info.get("code") or not (info.get("unionId") or info.get("openId")):
            self.logger.warning(
                "DingTalk users/me returned no identity: 检查 Contact.User.Read 权限",
                code=info.get("code"), message=info.get("message"),
            )
            return None

        union_id = (info.get("unionId") or info.get("unionid")
                    or info.get("openId") or info.get("openid") or "")
        app_token = self._app_token()
        if not app_token:
            self.logger.warning("DingTalk app token unavailable; cannot read contact email")
            return info
        userid = self._userid(app_token, union_id)
        if not userid:
            return info
        org_email, employee_email = self._contact_emails(app_token, userid)
        info["org_email"] = org_email
        info["employee_email"] = employee_email
        info["dingtalk_userid"] = userid
        if not (org_email or employee_email):
            self.logger.warning(
                "DingTalk contact has no org_email/email; "
                "检查通讯录邮箱等个人信息权限与成员资料",
                union_id=union_id,
            )
        return info


class DingTalkOAuthRedirect(OAuthRedirect):
    client_class = DingTalkOAuth2Client


class DingTalkOAuth2Callback(OAuthCallback):
    client_class = DingTalkOAuth2Client

    def get_user_id(self, info: dict[str, Any]) -> str | None:
        return info.get("unionId") or info.get("unionid") or info.get("openId")


@registry.register()
class DingTalkType(SourceType):
    """DingTalk / 钉钉 source type."""

    callback_view = DingTalkOAuth2Callback
    redirect_view = DingTalkOAuthRedirect
    verbose_name = "DingTalk / 钉钉"
    name = "dingtalk"

    urls_customizable = False
    authorization_url = AUTH_URL
    access_token_url = USER_TOKEN_URL
    profile_url = USER_ME_URL

    def get_base_user_properties(self, *args, **kwargs) -> dict[str, Any]:
        """按企业邮箱、员工邮箱、个人邮箱的顺序匹配现有用户并输出 email。"""
        info: dict[str, Any] = kwargs.get("info") or (args[-1] if args else {})
        union_id = info.get("unionId") or info.get("unionid") or info.get("openId") or ""
        candidates = [
            (info.get("org_email") or "").strip(),
            (info.get("employee_email") or "").strip(),
            (info.get("email") or "").strip(),
        ]

        try:
            from authentik.core.models import User
        except Exception:
            User = None

        email = ""
        for candidate in candidates:
            if not candidate:
                continue
            if User is not None:
                existing = User.objects.filter(email__iexact=candidate).first()
                if existing and existing.email:
                    email = existing.email
                    break
            if not email:
                email = candidate

        if not email:
            LOGGER.warning(
                "DingTalk has no contact/enterprise email (unionId=%s); "
                "email_link will deny this login", union_id,
            )

        return {
            "username": union_id,
            "name": info.get("nick") or union_id,
            "email": email,
            "attributes": {
                "dingtalk_unionid": union_id,
                "dingtalk_openid": info.get("openId") or "",
                "dingtalk_userid": info.get("dingtalk_userid") or "",
                "dingtalk_email": email,
                "dingtalk_org_email": candidates[0],
                "dingtalk_employee_email": candidates[1],
                "dingtalk_personal_email": candidates[2],
                "dingtalk_mobile": info.get("mobile") or "",
            },
        }
