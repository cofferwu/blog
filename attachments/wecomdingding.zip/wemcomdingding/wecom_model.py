"""在管理界面「新建源」向导中提供「WeCom / 企业微信」类型。

本模块由 patch_apps.py 注入的 import_models() 在 Django 加载模型阶段导入，
与 authentik 内置的 WeChatOAuthSource 等类处于同一时机。
向导的类型列表来自 Source.__subclasses__()，与 SourceType registry 相互独立。
"""

from authentik.core.api.object_types import CreatableType
from authentik.sources.oauth.models import OAuthSource


class WeComOAuthSource(CreatableType, OAuthSource):
    """Social login using WeCom (企业微信)."""

    class Meta:
        abstract = True
        app_label = "authentik_sources_oauth"
        verbose_name = "WeCom OAuth Source"
        verbose_name_plural = "WeCom OAuth Sources"
