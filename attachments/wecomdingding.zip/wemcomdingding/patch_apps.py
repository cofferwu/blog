"""给容器内的 sources/oauth/apps.py 打幂等补丁，注册 WeCom 与 DingTalk 两个 SourceType。

1. 把两个 types 模块加入 AUTHENTIK_SOURCES_OAUTH_TYPES（registry 列表）。
2. 覆写/补齐 import_models()，在 Django 加载模型时导入两个向导 model。

对「干净 apps.py」与「已打过 WeCom 补丁的 apps.py」都幂等，可重复执行。
必须作用于从运行容器取出的 apps.py；升级 authentik 后要重新 prepare。

用法：python patch_apps.py ./apps.py
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

TYPE_MODULES = (
    "authentik.sources.oauth.types.wecom",
    "authentik.sources.oauth.types.dingtalk",
)
WIZARD_MODULES = (
    "authentik.sources.oauth.wecom_model",
    "authentik.sources.oauth.dingtalk_model",
)
LIST_MARKER = "AUTHENTIK_SOURCES_OAUTH_TYPES = ["
IMPORT_MARKER = "def import_models"
ANCHORS = ("    def import_related(self):", "    @property\n    def schedule_specs")

IMPORT_MODELS = '''    def import_models(self):
        """Load custom wizard models while Django imports models."""
        super().import_models()
        from importlib import import_module

        import_module("authentik.sources.oauth.wecom_model")
        import_module("authentik.sources.oauth.dingtalk_model")

'''

IMPORT_MODELS_RE = re.compile(
    r"(?m)^(    def import_models\(self\):.*?)(?=^    (?:def |@property)|\Z)",
    re.S,
)


def add_wizard_imports(text: str, modules: tuple[str, ...]) -> tuple[str, list[str]]:
    """在已存在的 import_models() 方法体内补齐缺失的 import_module 行。"""
    match = IMPORT_MODELS_RE.search(text)
    if match is None:
        return text, []
    lines = match.group(1).splitlines(keepends=True)
    changed: list[str] = []

    if not any("from importlib import import_module" in line for line in lines):
        for i, line in enumerate(lines):
            if "super().import_models()" in line:
                indent = line[: len(line) - len(line.lstrip())]
                lines.insert(i + 1, f"{indent}from importlib import import_module\n")
                break

    for mod in modules:
        if any(f'import_module("{mod}")' in line for line in lines):
            continue
        candidates = [
            i for i, line in enumerate(lines)
            if "import_module(" in line and "from importlib" not in line
        ]
        if candidates:
            anchor = candidates[-1]
        else:
            anchor = next(
                (i for i, line in enumerate(lines) if "super().import_models()" in line),
                None,
            )
        if anchor is None:
            continue
        indent = lines[anchor][: len(lines[anchor]) - len(lines[anchor].lstrip())]
        lines.insert(anchor + 1, f'{indent}import_module("{mod}")\n')
        changed.append(mod)

    return text[: match.start(1)] + "".join(lines) + text[match.end(1) :], changed


def patch(path: str) -> int:
    target = Path(path)
    if not target.is_file():
        print(f"ERROR: {path} not found", file=sys.stderr)
        return 1

    text = target.read_text(encoding="utf-8")
    original = text
    changed: list[str] = []

    for mod in TYPE_MODULES:
        if f'"{mod}"' in text:
            print(f"already registered: {mod}")
            continue
        if LIST_MARKER not in text:
            print("ERROR: AUTHENTIK_SOURCES_OAUTH_TYPES not found", file=sys.stderr)
            return 1
        text = text.replace(LIST_MARKER, f'{LIST_MARKER}\n    "{mod}",', 1)
        changed.append(f"registry: {mod}")

    if IMPORT_MARKER not in text:
        anchor = next((a for a in ANCHORS if a in text), None)
        if anchor is None:
            print("ERROR: no safe insertion point found", file=sys.stderr)
            return 1
        text = text.replace(anchor, IMPORT_MODELS + anchor, 1)
        changed.append("import_models() hook")
    else:
        text, added = add_wizard_imports(text, WIZARD_MODULES)
        changed.extend(f"wizard: {mod}" for mod in added)
        if not added:
            print("already present: all wizard imports")

    missing = [m for m in WIZARD_MODULES if f'import_module("{m}")' not in text]
    if missing:
        print("ERROR: 无法在 import_models() 内补齐: " + ", ".join(missing), file=sys.stderr)
        return 1

    if text != original:
        target.write_text(text, encoding="utf-8")
        print(f"patched {path}: " + ", ".join(changed))
    else:
        print(f"nothing to do, {path} is already fully patched")
    return 0


if __name__ == "__main__":
    sys.exit(patch(sys.argv[1] if len(sys.argv) > 1 else "./apps.py"))
